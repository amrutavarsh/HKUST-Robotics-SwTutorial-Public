#include "adc.h"

#include "rcc.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"

static u16 ADC_READINGS[16] = {0};
static u8 NO_OF_ADC_PORTS = 0;

ADCPort ADC_IO_1 = {GPIO1, 0, ADC_Channel_0};
ADCPort ADC_IO_2 = {GPIO2, 0, ADC_Channel_1};
ADCPort ADC_IO_3 = {GPIO3, 0, ADC_Channel_2};
ADCPort ADC_IO_4 = {GPIO4, 0, ADC_Channel_3};
ADCPort ADC_IO_5 = {GPIO5, 0, ADC_Channel_4};
ADCPort ADC_IO_6 = {GPIO6, 0, ADC_Channel_5};
ADCPort ADC_IO_7 = {GPIO7, 0, ADC_Channel_6};
ADCPort ADC_IO_8 = {GPIO8, 0, ADC_Channel_7};

ADCPort ADC_TEMP = {0, 0, ADC_Channel_TempSensor};
ADCPort ADC_VREF = {0, 0, ADC_Channel_Vrefint};

static const enum {
	ADC_DMA_MODE, ADC_IT_MODE, ADC_DMA_PLUS_IT_MODE,
} ADC_MODE = ADC_DMA_MODE; // Ignore this warning, it is used by the preprocessor

/**
 * @brief      Initialize an ADC Channel
 *
 * @param      adc_port  The ADC Port
 */
void adc_channel_init(ADCPort* adc_port) {
	adc_port->index = NO_OF_ADC_PORTS++;
	if(adc_port->pin) gpio_init(adc_port->pin, GPIO_Mode_AIN);
	ADC_RegularChannelConfig(ADC1, adc_port->channel, NO_OF_ADC_PORTS, ADC_SampleTime_239Cycles5);
	// (SampleTime[239.5] + Tconv[12.5])/ADCCLK[72MHz/6] = 21us -> 47.62kHz (/NO_OF_ADC_PORTS)
}

/**
 * @brief      Initialize the DMA Channel for the ADC 
 * 			to automatically read the measurement into the ADC_READINGS buffer
 */	
static void adc_dma_init(void) {
	#if ADC_MODE != ADC_IT_MODE

	dma_rcc_init(DMA1);

	DMA_InitTypeDef DMA_InitStructure;
	DMA_DeInit(DMA1_Channel1);
	
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = NO_OF_ADC_PORTS;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)&ADC_READINGS[0];
	
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	
	DMA_Cmd(DMA1_Channel1,ENABLE);
	
	ADC_DMACmd(ADC1, ENABLE);

	#endif
}

/**
 * @brief      Initialize the ADC Conversion Interrupt
 * 				Will cause an interrupt to be called after each sequence of conversions
 * 				One sequence means each channels is measured once
 */
static void adc_it_init(void) {
	#if ADC_MODE != ADC_DMA_MODE

	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

	#if ADC_MODE == ADC_IT_MODE
		NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
		NVIC_Init(&NVIC_InitStructure);
		ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);
	#elif ADC_MODE == ADC_DMA_PLUS_IT_MODE
		NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
		NVIC_Init(&NVIC_InitStructure);
		DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
	#endif

	#endif
}

/**
 * @brief      Initialize the Whole ADC
 * @note       IMPORTANT: must be called after all the channels are initialized
 */
void adc_init() {
	adc_rcc_init(ADC1);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);

	ADC_InitTypeDef ADC_InitStructure;
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = NO_OF_ADC_PORTS;
	ADC_Init(ADC1, &ADC_InitStructure);

	adc_dma_init();
	adc_it_init();

	ADC_Cmd(ADC1, ENABLE);

	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1));
	
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);

}

/**
 * @brief      Gets the latest ADC reading corresponding to the given ADC Port
 *
 * @param      adc   The ADC Port
 *
 * @return     The ADC Reading
 */
u16 get_adc(ADCPort* adc) {
	return ADC_READINGS[adc->index];
}

static u8 adc_converted_channel = 0;
#define ADC_READING (ADC_READINGS[adc_converted_channel])

/**
 * @brief      The Interrupt Handler for ADC1 and ADC2
 */
void ADC1_2_IRQHandler(void) {
	if (ADC_GetITStatus(ADC1, ADC_IT_EOC)) {
		ADC_READING = ADC_GetConversionValue(ADC1); // This is basically what the DMA does lol

		adc_converted_channel++;
		ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
	}
}

void DMA1_Channel1_IRQHandler(void) {
	if (DMA_GetITStatus(DMA1_IT_TC1)) {
		adc_converted_channel++;
		DMA_ClearITPendingBit(DMA1_IT_TC1);
	}
}
