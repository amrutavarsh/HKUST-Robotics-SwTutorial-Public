#ifndef __ADC_H
#define __ADC_H

/*	
 *	Base ADC Library for 2018-19 Internal Mainboard
 *
 *  Author  : Anshuman Medhi
 *  Contact : amedhi@connect.ust.hk 
 *						68925193
 *
 */

#include "gpio.h"

typedef struct {
	const GPIOPin* pin;
	u8 index;
	u8 channel;
} ADCPort;

/**
 * Predefined ADC Ports, Feel free to read the Schematic/Datasheet and create your own
 * ADC_PORT_X are the dedicated ADC ports for use with the Magnetic Wire Sensors, 
 * 		they cannot be used for other analog signals or GPIO due to external onboard circuitry
 * 	ADC_IO_X are reconfiguration of the GPIO Ports as ADC Inputs
 */
extern ADCPort ADC_IO_1,ADC_IO_2,ADC_IO_3,ADC_IO_4,ADC_IO_5,ADC_IO_6,ADC_IO_7,ADC_IO_8;
#define ADC_PORT_1 &ADC_IO_1
#define ADC_PORT_2 &ADC_IO_2
#define ADC_PORT_3 &ADC_IO_3
#define ADC_PORT_4 &ADC_IO_4
#define ADC_PORT_5 &ADC_IO_5
#define ADC_PORT_6 &ADC_IO_6
#define ADC_PORT_7 &ADC_IO_7
#define ADC_PORT_8 &ADC_IO_8

/**
 * @brief      Initialize an ADC Channel
 *
 * @param      adc_port  The ADC Port
 */
void adc_channel_init(ADCPort* adc_port);

/**
 * @brief      Initialize the Whole ADC
 * @note       IMPORTANT: must be called after all the channels are initialized
 */
void adc_init(void);

/**
 * @brief      Initialize the ADC Conversion Interrupt
 * 				Will cause an interrupt to be called after each sequence of conversions
 * 				One sequence means each channels is measured once
 */
void adc_it_init(void);

/**
 * @brief      Gets the latest ADC reading corresponding to the given ADC Port
 *
 * @param      adc   The ADC Port
 *
 * @return     The ADC Reading
 */
u16 get_adc(ADCPort* adc_port);

#endif
