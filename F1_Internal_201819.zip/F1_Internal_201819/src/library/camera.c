#include "camera.h"

#include "ov7725.h"
#include "lcd_main.h"

ColorMode color_mode = RGBColour;
CameraState cam_state = CAM_NOT_INITED;
uint8_t image[IMAGE_LENGTH][IMAGE_WIDTH];
uint16_t colour_image[IMAGE_LENGTH][IMAGE_WIDTH];
u8 camera_inited = 0;

/**
 * @brief      Configure the OV7725 Camera
 *
 * @return     Successful communication, can assume successfull configuration
 */
static u8 camera_config(void) {
	i2c_init(CAM_SCCB);

	if (!i2c_write(CAM_SCCB, OV7725ADR, COM7, 0x80)) return 0;

	u8 tmp=0;

	if (!i2c_read(CAM_SCCB, OV7725ADR, PID, &tmp, 1)) return 0;
	if (tmp != OV7725ID_PID) return 0;
	if (!i2c_read(CAM_SCCB, OV7725ADR, VER, &tmp, 1)) return 0;
	if (tmp != OV7725ID_VER) return 0;

	const OV7725REG* reg = camera_config_seq;
	while (reg->address != 0xFF) {
		if (!i2c_write(CAM_SCCB, OV7725ADR, reg->address, reg->data)) return 0;
	}

	if (color_mode == GreyScale) {
		//8bit greyscale
		i2c_write(CAM_SCCB, OV7725ADR, COM7, 0x40);
		//16bit greyscale - capture with colour_image
		//sccbWriteByte(SDE,0x26);
		//sccbWriteByte(UFix,0x80);
		//sccbWriteByte(VFix,0x80);
	}

	return 1;
}

/**
 * @brief      Initialize the Camera and FIFO Interface
 *
 * @param[in]  _color_mode  The color mode
 *
 * @return     Successful configuration
 */
u8 camera_init(ColorMode _color_mode) {
	color_mode = _color_mode;

	if (!camera_config()) return 0;
	// while (!camera_config());

	gpio_init(CAM_OE, GPIO_Mode_Out_PP);
	gpio_init(CAM_WEN, GPIO_Mode_Out_PP);
	gpio_init(CAM_WRST, GPIO_Mode_Out_PP);
	gpio_init(CAM_RCLK, GPIO_Mode_Out_PP);
	gpio_init(CAM_RRST, GPIO_Mode_Out_PP);

	gpio_init(CAM_VSYNC, GPIO_Mode_IN_FLOATING);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = CAM_DMASK;
	GPIO_Init(CAM_DPORT, &GPIO_InitStructure);

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = CAM_VSYNC_IRQ;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	EXTI_InitTypeDef EXTI_InitStructure;
	GPIO_EXTILineConfig(CAM_VSYNC_PSRC);
	EXTI_InitStructure.EXTI_Line = CAM_VSYNC_EXTI;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling ; 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	EXTI_GenerateSWInterrupt(CAM_VSYNC_EXTI);

	gpio_reset(CAM_OE);
	gpio_set(CAM_WEN);

	cam_state = CAM_FIFO_EMPTY;

	return 1;
}

/**
 * CAMERA FIFO SEQUENCE
 * 
 * @brief FIFO_EMPTY 
 * 		-> VSYNC [SENSOR FRAME CAPTURED, OUTPUTTING DATA TO FIFO]
 * 		-> FIFO_FILLING
 * 		-> VSYNC [PREV FRAME BUFFERED IN FIFO, NEXT FRAME CAPTURED]
 * 		-> FIFO_FULL
 * 		-> STM32 READING DATA FROM FIFO TO FILL RAM BUFFER
 * 		-> FIFO_EMPTY
 * 		-> {loop}
 * 
 * 	It is left as an exercise to the reader to identify the ineffiency and consider a solution
 * 
 */

/**
 * @brief      Capture a frame from the Cameras FIFO Buffer in the colour_image[][] buffer
 *
 * @return     Attempting to capture from the FIFO when FIFO is not full will lead to failure (0)
 */
u8 camera_capture(void) {
	if (cam_state != CAM_FIFO_FULL) return 0;	

	CAM_FIFO_PREPARE();

	for (int i = 0; i < IMAGE_LENGTH; ++i){
		for (int j = 0; j < IMAGE_WIDTH; ++j) {
			CAM_FIFO_READ(&colour_image[j][i]);
		}
	}

	cam_state = CAM_FIFO_EMPTY;

	return 1;
}

u8 camera_capture_and_print(u8 x, u8 y) {
	if (cam_state != CAM_FIFO_FULL) return 0;	

	CAM_FIFO_PREPARE();
	tft_set_region(x, y, IMAGE_LENGTH, IMAGE_WIDTH);

	for (int i = 0; i < IMAGE_LENGTH; ++i){
		for (int j = 0; j < IMAGE_WIDTH; ++j) {
			CAM_FIFO_READ(&colour_image[j][i]);
			tft_write_color(colour_image[j][i]);
		}
	}

	
	cam_state = CAM_FIFO_EMPTY;

	return 1;
}

/**
 * @brief      Capture a frame from the Cameras FIFO Buffer, in 8 bits per pixel mode, only available in Greyscale mode
 *	into the image[][] buffer
 *
 * @return     Attempting to capture from the FIFO when FIFO is not full will lead to failure (0)
 */
u8 camera_capture8(void) {
	if (cam_state != CAM_FIFO_FULL) return 0;	
	if (color_mode != GreyScale) return 0;

	CAM_FIFO_PREPARE();

	for (int i = 0; i < IMAGE_LENGTH; ++i){
		for (int j = 0; j < IMAGE_WIDTH; ++j) {
			CAM_FIFO_READ8(&image[j][i]);
		}
	}
	
	cam_state = CAM_FIFO_EMPTY;

	return 1;
}
u8 camera_capture8_and_print(u8 x, u8 y) {
	if (cam_state != CAM_FIFO_FULL) return 0;	
	if (color_mode != GreyScale) return 0;

	CAM_FIFO_PREPARE();
	tft_set_region(x, y, IMAGE_LENGTH, IMAGE_WIDTH);

	for (int i = 0; i < IMAGE_LENGTH; ++i){
		for (int j = 0; j < IMAGE_WIDTH; ++j) {
			CAM_FIFO_READ8(&image[j][i]);
			tft_write_color(grey_to_rgb565(image[j][i]));
		}
	}
	
	cam_state = CAM_FIFO_EMPTY;

	return 1;
}

/**
 * @brief      Flip the R and B components of a given RGB565 pixel
 * 			consider using if the image is discoloured, however also consider the performance penalty
 *
 * @param[in]  input  The input pixel
 *			   [[RGB565]]<->BGR565
 *
 * @return     RGB565<->[[BGR565]]
 */
inline uint16_t flip_rb(uint16_t input) {
	return (input>>11)|(input<<11)|(input&0x07E0);
}

/**
 * @brief      Convert a 8bit grayscale pixel into 'equivalent' RGB565 value 
 *
 * @param[in]  input  The input
 *
 * @return     { description_of_the_return_value }
 */
inline uint16_t grey_to_rgb565(uint8_t input) {
	return ((input << 8) & 0xF800) | ((input << 3) & 0x07E0) | (input >> 3);
}

/**
 * @brief      Handle the VSYNC updates for CAM_FIFO state
 */
void CAM_VSYNC_HANDLER(void) {
	if (EXTI_GetITStatus(CAM_VSYNC_EXTI) != RESET) {
		if (cam_state==CAM_FIFO_EMPTY) {
			gpio_reset(CAM_WRST);
			gpio_reset(CAM_WEN);
			cam_state=CAM_FIFO_FILLING;
			gpio_set(CAM_WEN);
			gpio_set(CAM_WRST);
		} else if (cam_state==CAM_FIFO_FILLING) {
			gpio_reset(CAM_WEN);
			cam_state = CAM_FIFO_FULL;
		}
		EXTI_ClearITPendingBit(CAM_VSYNC_EXTI);
	}
}
