#ifndef __CAMERA_H
#define __CAMERA_H

/*	
 *	OV7725 Camera Library with pure GPIO Bit-Banding
 *
 *  Author  : Anshuman Medhi
 *  Contact : amedhi@connect.ust.hk 
 *						68925193
 *
 */

#include "gpio.h"

#define IMAGE_LENGTH 90
#define IMAGE_WIDTH  120

typedef enum {
	RGBColour = 0,
	GreyScale
} ColorMode;

typedef enum {
	CAM_FIFO_EMPTY, CAM_FIFO_FILLING, CAM_FIFO_FULL, CAM_FIFO_READING, CAM_NOT_INITED
} CameraState;

extern uint8_t image[IMAGE_LENGTH][IMAGE_WIDTH];
extern uint16_t colour_image[IMAGE_LENGTH][IMAGE_WIDTH];

/**
 * @brief      Initialize the Camera and FIFO Interface
 *
 * @param[in]  _color_mode  The color mode
 *
 * @return     Successful configuration
 */
u8 camera_init(ColorMode color_mode);

/**
 * @brief      Capture a frame from the Cameras FIFO Buffer
 *
 * @param      buffer  The buffer
 *
 * @return     Attempting to capture from the FIFO when FIFO is not full will lead to failure (0)
 */
u8 camera_capture(void);

/**
 * @brief      Capture a frame from the Cameras FIFO Buffer, into a 8 bits per pixel mode, only available in Greyscale mode
 *
 * @param      buffer  The buffer
 *
 * @return     Attempting to capture from the FIFO when FIFO is not full will lead to failure (0)
 */
u8 camera_capture8(void);

/**
 * @brief      Flip the R and B components of a given RGB565 pixel
 * 			consider using if the image is discoloured, however also consider the performance penalty
 *
 * @param[in]  input  The input pixel
 *			   [[RGB565]]<->BGR565
 *
 * @return     RGB565<->[[BGR565]]
 */
inline uint16_t flip_rb(uint16_t input);

/**
 * @brief      Convert a 8bit grayscale pixel into 'equivalent' RGB565 value 
 *
 * @param[in]  input  The input
 *
 * @return     { description_of_the_return_value }
 */
inline uint16_t grey_to_rgb565(uint8_t input);

#endif
