#include "i2c.h"
#include "rcc.h"

/**
 * @brief      Convenience macros for Set/Reset the I2C SCL pin
 *
 * @return     N/A
 */
#define SCL_H() gpio_set(i2c->scl)
#define SCL_L() gpio_reset(i2c->scl)

/**
 * @brief      Convenience macros for Set/Reset/Write/Read of the I2C SDA pin
 *
 * @param      B     Bit to write or nothing
 *
 * @return     Nothing or logic value on the SDA pin
 *
 * @note       SDA is configured as output open drain, which means
 *             0=Pull-down-to-GND, 1=Hi-Z in Hi-Z mode it can act like an input
 *             (IN_FLOATING) as well
 */
#define SDA_W(B) gpio_write(i2c->sda, (B))
#define SDA_H() gpio_set(i2c->sda)
#define SDA_L() gpio_set(i2c->sda)
#define SDA_R() gpio_read(i2c->sda)

/**
 * @brief      Convenience macros to control the 8th R/W bit of the address as
 *             per the I2C protocol
 *
 * @param      addr  The address of the I2C slave device to talk to
 *
 * @return     Address with final bit Set/Reset
 */
#define READ_FROM(addr) ((addr)|0x01)
#define WRITE_TO(addr) ((addr)&(~0x01))

/**
 * @brief      Initialize the "I2C Peripheral"
 *
 * @param[in]  i2c   Handle of the I2C Peripheral
 */
void i2c_init(const I2CPort* i2c) {
	gpio_init(i2c->scl, GPIO_Mode_Out_OD);
	gpio_init(i2c->sda, GPIO_Mode_Out_OD);

	SCL_H();
	SDA_H();

	tim_rcc_init(I2C_TIM);
	I2C_TIM->PSC = 0;
}

/**
 * @brief      Reset the status flags of the I2C Timer
 */
#define i2c_clock_reset() I2C_TIM->SR = 0

/**
 * @brief      Stop the I2C Timer 
 */
#define i2c_clock_stop() I2C_TIM->CR1 &= ~TIM_CR1_CEN

/**
 * @brief      Check for the status of the I2C Timer for when a Period is Elapsed
 *
 * @note Remember to stop the timer (for one-time delay) or reset the status flags (for a continuous software clock)
 */
#define i2c_clock_done() (I2C_TIM->SR & TIM_SR_UIF)

/**
 * @brief      Start the I2C Timer as a clock 
 */
static void i2c_clock_start(const I2CPort* i2c) {
	i2c_clock_reset();
	I2C_TIM->ARR = i2c->clk_psc;
	I2C_TIM->CR1 |= TIM_CR1_CEN;
}
/**
 * @brief      Wait for a clock period to elapse, and reset the status register, for continuous clock mode
 */
static void i2c_tock() {
	while(!i2c_clock_done());
	i2c_clock_reset();
}

/**
 * @brief      "Release" the I2C SDA and wait for the slave device to ACK
 *
 * @param[in]  i2c   I2C Peripheral Handle
 *
 * @return     Whether we received an ACK
 */
static u8 i2c_chk_ack(const I2CPort* i2c) {
	SDA_H();

	while(!i2c_clock_done()) {
		if (!SDA_R()) return 1;
	}
	i2c_clock_reset();
	return !SDA_R();
}
/**
 * @brief      Pull the I2C SDA and check for start condition
 *
 * @param[in]  i2c   I2C Peripheral Handle
 *
 * @return     Start Condition Succesful
 */
static u8 i2c_chk_start(const I2CPort* i2c) {
	SDA_L();

	while(!i2c_clock_done()) {
		if (!SDA_R()) return 1;
	}
	i2c_clock_reset();
	return !SDA_R();
}
/**
 * @brief      SDA High for 1 clock period
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_sda_h(const I2CPort* i2c) {
	SDA_H();
	i2c_tock();
}
/**
 * @brief      Write bit to SDA for 1 clock period
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  b     bit to write
 */
static void i2c_sda_w(const I2CPort* i2c, u8 b) {
	SDA_W(b);
	i2c_tock();
}
/**
 * @brief      SDA Low for 1 clock period
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_sda_l(const I2CPort* i2c) {
	SDA_L();
	i2c_tock();
}
/**
 * @brief      SCL High for 1 clock period
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_scl_h(const I2CPort* i2c) {
	SCL_H();
	i2c_tock();
}
/**
 * @brief      SCL Low for 1 clock period
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_scl_l(const I2CPort* i2c) {
	SCL_L();
	i2c_tock();
}

/**
 * @brief      I2C Start Communication
 *
 * @param[in]  i2c   I2C Peripheral Handle
 *
 * @return     Whether start condition was received successfully
 */
static u8 i2c_start(const I2CPort* i2c) {
	SCL_H();
	i2c_sda_h(i2c);
	return i2c_chk_start(i2c);
}
/**
 * @brief      I2C Stop Communication
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_stop(const I2CPort* i2c) {
	i2c_scl_l(i2c);
	i2c_sda_l(i2c);
	i2c_scl_h(i2c);
	i2c_sda_h(i2c);
}

/**
 * @brief      I2C Send ACK
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_ack(const I2CPort* i2c) {
	i2c_scl_l(i2c);
	i2c_sda_l(i2c);
	i2c_scl_h(i2c);
	i2c_sda_l(i2c);
}
/**
 * @brief      I2C Send NACK
 *
 * @param[in]  i2c   I2C Peripheral Handle
 */
static void i2c_nack(const I2CPort* i2c) {
	i2c_scl_l(i2c);
	i2c_sda_h(i2c);
	i2c_scl_h(i2c);
	i2c_sda_l(i2c);
}
/**
 * @brief      I2C Wait for ACK from Slave Device
 *
 * @param[in]  i2c   I2C Peripheral Handle
 *
 * @return     { description_of_the_return_value }
 */
static u8 i2c_wait_ack(const I2CPort* i2c) {
	i2c_scl_l(i2c);
	i2c_sda_h(i2c);
	i2c_scl_h(i2c);
	u8 acked = i2c_chk_ack(i2c);
	i2c_scl_l(i2c);
	return acked;
}

/**
 * @brief      I2C Send a byte
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  byte  The byte
 */
static void i2c_send(const I2CPort* i2c, u8 byte) {
	uint8_t i = 8;
	while (i--) {
		i2c_scl_l(i2c);
		i2c_sda_w(i2c, byte & 0x80);
		byte<<=1;
		i2c_scl_h(i2c);
	}
	SCL_L();
}

/**
 * @brief      I2C Receive a byte
 *
 * @param[in]  i2c   I2C Peripheral Handle
 *
 * @return     The received byte
 */
static u8 i2c_recv(const I2CPort* i2c) {
	uint8_t i = 8;
	uint8_t byte = 0;
	SDA_H();
	while (i--) {
		byte <<= 1;
		i2c_scl_l(i2c);
		i2c_scl_h(i2c);
		if (SDA_R()) byte |= 1; 
	}
	SCL_L();
	return byte;
}

/**
 * @brief      I2C Start Communication with a Slave
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  addr  The address of the Slave Device
 * @note The 8th bit transmitted aka the LSB is the R/W bit, 
 * 		which can be set using the READ_FROM and WRITE_TO macros for convenience
 *
 * @return     Whether Start Condition and ACK was succesful
 */
static u8 i2c_slave_start(const I2CPort* i2c, u8 addr) {
	if (!i2c_start(i2c)) return 0;
	
	i2c_send(i2c, addr);
	
	if (!i2c_wait_ack(i2c)) {
		i2c_stop(i2c);
		return 0;
	}

	return 1;
}

/**
 * @brief      I2C Write a byte and wait for ACK
 * @note I2C Communication must be already started using i2c_slave_start()
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  byte  The byte to send
 */
static void i2c_slave_write(const I2CPort* i2c, u8 byte) {
	i2c_send(i2c, byte);

	i2c_wait_ack(i2c);
}

/**
 * @brief      I2C Write a byte to a specific register/address in the slave device
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  addr  The address of the Slave Device
 * @param[in]  reg   The register to write to
 * @param[in]  data  The data to write
 *
 * @return     Whether communication was started correctly
 * @note not neccessarily successfully written
 */
u8 i2c_write(const I2CPort* i2c, u8 addr, u8 reg, u8 data) {
	i2c_clock_start(i2c);

	if (!i2c_slave_start(i2c, WRITE_TO(addr))) return 0;

	i2c_slave_write(i2c, reg);
	i2c_slave_write(i2c, data);

	i2c_stop(i2c);

	return 1;
}

/**
 * @brief      Read specific amount of bytes from a register/series of registers of a slave device
 *
 * @param[in]  i2c   I2C Peripheral Handle
 * @param[in]  addr  The address of the Slave Device
 * @param[in]  reg   The (starting) register to read from
 * @param      buf   The buffer to read data into
 * @param[in]  len   The amount of data to read
 *
  * @return     Whether communication was started correctly
 * @note not neccessarily successfully written
 */
u8 i2c_read(const I2CPort* i2c, u8 addr, u8 reg, u8* buf, u8 len) {
	i2c_clock_start(i2c);

	if (!i2c_slave_start(i2c, WRITE_TO(addr))) return 0;

	i2c_slave_write(i2c, reg);

	i2c_stop(i2c);

	if (!i2c_slave_start(i2c, READ_FROM(addr))) return 0;

	while (len--) {
		*buf = i2c_recv(i2c);
		if (len==1) i2c_nack(i2c);
		else i2c_ack(i2c);
		buf++;
	}

	i2c_stop(i2c);

	return 1;
}
