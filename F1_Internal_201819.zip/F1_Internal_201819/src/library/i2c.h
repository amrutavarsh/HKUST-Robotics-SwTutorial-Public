#ifndef __I2C_H
#define __I2C_H

#include "gpio.h"

/**
 * GPIO-based (bit-banging) library for I2C/SCCB because the stm32f1 i2c peripheral is buggy
 * 
 *  Author  : Anshuman Medhi
 *  Contact : amedhi@connect.ust.hk 
 *						68925193
 *						
 */

#define I2C_TIM TIM6

typedef struct {
	const GPIOPin* scl;
	const GPIOPin* sda;
	u16 clk_psc; // Frequency = BusClockSpeed / ClockPrescaler / 4
	             // ~400kHz -> 45
	             // ~100kHz -> 180
} I2CPort;

/**
 * @brief      Initialize the "I2C Peripheral"
 *
 * @param[in]  i2c   I2C Peripheral
 */
void i2c_init(const I2CPort* i2c);

/**
 * @brief      I2C Write a byte to a specific register/address in the slave device
 *
 * @param[in]  i2c   I2C Peripheral
 * @param[in]  addr  The address of the Slave Device
 * @param[in]  reg   The register to write to
 * @param[in]  data  The data to write
 *
 * @return     Whether communication was started correctly
 * @note not neccessarily successfully written
 */
u8 i2c_write(const I2CPort* i2c, u8 addr, u8 reg, u8 data);

/**
 * @brief      Read specific amount of bytes from a register/series of registers of a slave device
 *
 * @param[in]  i2c   I2C Peripheral
 * @param[in]  addr  The address of the Slave Device
 * @param[in]  reg   The (starting) register to read from
 * @param      buf   The buffer to read data into
 * @param[in]  len   The amount of data to read
 *
  * @return     Whether communication was started correctly
 * @note not neccessarily successfully written
 */
u8 i2c_read(const I2CPort* i2c, u8 addr, u8 reg, u8* buf, u8 len);

#endif
