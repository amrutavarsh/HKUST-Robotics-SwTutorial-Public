#ifndef __OV7725_H
#define __OV7725_H

/**
 * Internal Hardware Description of OV7725 Registers and Interface
 */

#include "i2c.h"

#define CAM_I2C              I2C1
#define CAM_SCL_TIM          TIM4
#define CAM_SCL_TOC          1
#define CAM_SDA              &PB9
#define CAM_SCL              &PB8

static const I2CPort _CAM_SCCB = {
	CAM_SCL, CAM_SDA, 45 //400kHz
};

#define CAM_SCCB &_CAM_SCCB

#define CAM_VSYNC_IRQ        EXTI9_5_IRQn
#define CAM_VSYNC_HANDLER    EXTI9_5_IRQHandler
#define CAM_VSYNC_EXTI       EXTI_Line5
#define CAM_VSYNC_PSRC       GPIO_PortSourceGPIOB, GPIO_PinSource5
#define CAM_VSYNC            &PC4


#define CAM_OE               &PC12

#define CAM_WEN              &PA12
#define CAM_WRST             &PD2

#define CAM_RCLK             &PA11
#define SET_CAM_RCLK()       GPIOA->BSRR = GPIO_Pin_11
#define RESET_CAM_RCLK()		GPIOA->BRR = GPIO_Pin_11

#define CAM_RRST             &PC5
#define SET_CAM_RRST()       GPIOC->BSRR = GPIO_Pin_5
#define RESET_CAM_RRST()		GPIOC->BRR = GPIO_Pin_5

#define CAM_DPORT            GPIOB
#define CAM_DMASK            0x00FF
#define CAM_READ_TO_H()      (((CAM_DPORT->IDR) & CAM_DMASK) << 8)
#define CAM_READ_TO_L()      ((CAM_DPORT->IDR) & CAM_DMASK)

static inline void CAM_FIFO_PREPARE() {
	RESET_CAM_RRST();
	RESET_CAM_RCLK();
	SET_CAM_RCLK();
	SET_CAM_RRST();
	RESET_CAM_RCLK();
	SET_CAM_RCLK();
}

static inline void CAM_FIFO_READ16(u16* buf) {
	RESET_CAM_RCLK();
	*buf = CAM_READ_TO_H();
	SET_CAM_RCLK();
	
	RESET_CAM_RCLK();
	*buf |= CAM_READ_TO_L();
	SET_CAM_RCLK();
}
static inline void CAM_FIFO_READ(u16* buf) {
	RESET_CAM_RCLK();
	*buf = CAM_READ_TO_L();
	SET_CAM_RCLK();

	RESET_CAM_RCLK();
	SET_CAM_RCLK();
}
static inline void CAM_FIFO_READ8(u8* buf) {
	RESET_CAM_RCLK();
	*buf = CAM_READ_TO_L();
	SET_CAM_RCLK();

	RESET_CAM_RCLK();
	SET_CAM_RCLK();
}

//ov7725 address define
#define OV7725ADR 0x42

//ov7725 product id
#define OV7725ID_PID 0x77
#define OV7725ID_VER 0x21

//	ov7725 register address definition
#define GAIN      0x00
	#if 0
	#define BLUE      0x01
	#define RED       0x02
	#define RED       0x02
	#define GREEN     0x03
	#endif
#define BAVG      0x05
#define GAVG      0x06
#define RAVG      0x07
#define AECH      0x08
#define COM2      0x09
#define PID       0x0A
#define VER       0x0B
#define COM3      0x0C
#define COM4      0x0D
#define COM5      0x0E
#define COM6      0x0F
#define AEC       0x10
#define CLKRC     0x11
#define COM7      0x12
#define COM8      0x13
#define COM9      0x14
#define COM10     0x15
#define REG16     0x16
#define HSTART    0x17
#define HSIZE     0x18
#define VSTRT     0x19
#define VSIZE     0x1A
#define PSHFT     0x1B
#define MIDH      0x1C
#define MIDL      0x1D
#define LAEC      0x1F
#define COM11     0x20
#define BDBase    0x22
#define BDMStep   0x23
#define AEW       0x24
#define AEB       0x25
#define VPT       0x26
#define REG28     0x28
#define HOutSize  0x29
#define EXHCH     0x2A
#define EXHCL     0x2B
#define VOutSize  0x2C
#define ADVFL     0x2D
#define ADVFH     0x2E
#define YAVE      0x2F
#define LumHTh    0x30
#define LumLTh    0x31
#define HREF      0x32
#define DM_LNL    0x33
#define DM_LNH    0x34
#define ADoff_B   0x35
#define ADoff_R   0x36
#define ADoff_Gb  0x37
#define ADoff_Gr  0x38
#define Off_B     0x39
#define Off_R     0x3A
#define Off_Gb    0x3B
#define Off_Gr    0x3C
#define COM12     0x3D
#define COM13     0x3E
#define COM14     0x3F
#define COM16     0x41
#define TGT_B     0x42
#define TGT_R     0x43
#define TGT_Gb    0x44
#define TGT_Gr    0x45
#define LC_CTR    0x46
#define LC_XC     0x47
#define LC_YC     0x48
#define LC_COEF   0x49
#define LC_RADI   0x4A
#define LC_COEFB  0x4B 
#define LC_COEFR  0x4C
#define FixGain   0x4D
#define AREF1     0x4F
#define AREF6     0x54
#define UFix      0x60
#define VFix      0x61
#define AWBb_blk  0x62
#define AWB_Ctrl0 0x63
#define DSP_Ctrl1 0x64
#define DSP_Ctrl2 0x65
#define DSP_Ctrl3 0x66
#define DSP_Ctrl4 0x67
#define AWB_bias  0x68
#define AWBCtrl1  0x69
#define AWBCtrl2  0x6A
#define AWBCtrl3  0x6B
#define AWBCtrl4  0x6C
#define AWBCtrl5  0x6D
#define AWBCtrl6  0x6E
#define AWBCtrl7  0x6F
#define AWBCtrl8  0x70
#define AWBCtrl9  0x71
#define AWBCtrl10 0x72
#define AWBCtrl11 0x73
#define AWBCtrl12 0x74
#define AWBCtrl13 0x75
#define AWBCtrl14 0x76
#define AWBCtrl15 0x77
#define AWBCtrl16 0x78
#define AWBCtrl17 0x79
#define AWBCtrl18 0x7A
#define AWBCtrl19 0x7B
#define AWBCtrl20 0x7C
#define AWBCtrl21 0x7D 
#define GAM1      0x7E
#define GAM2      0x7F
#define GAM3      0x80
#define GAM4      0x81
#define GAM5      0x82
#define GAM6      0x83
#define GAM7      0x84
#define GAM8      0x85
#define GAM9      0x86
#define GAM10     0x87
#define GAM11     0x88
#define GAM12     0x89
#define GAM13     0x8A
#define GAM14     0x8B
#define GAM15     0x8C
#define SLOP      0x8D
#define DNSTh     0x8E
#define EDGE0     0x8F
#define EDGE1     0x90
#define DNSOff    0x91
#define EDGE2     0x92
#define EDGE3     0x93
#define MTX1      0x94
#define MTX2      0x95
#define MTX3      0x96
#define MTX4      0x97
#define MTX5      0x98
#define MTX6      0x99
#define MTX_Ctrl  0x9A
#define BRIGHT    0x9B
#define CNST      0x9C
#define UVADJ0    0x9E
#define UVADJ1    0x9F
#define SCAL0     0xA0
#define SCAL1     0xA1
#define SCAL2     0xA2
#define SDE       0xA6
#define USAT      0xA7
#define VSAT      0xA8
#define HUECOS    0xA9
#define HUESIN    0xAA
#define SIGN      0xAB
#define DSPAuto   0xAC
																			
//	register default value
typedef struct
{
	uint8_t address;
	uint8_t data;
}OV7725REG;

static const OV7725REG camera_config_seq[] =
{
	{COM2,			0x03},
	{CLKRC,     0x00},
	{COM7,      0x46},
	//default value for QVGA
	{HSTART,    0x3f},
	{HSIZE,     0x50},
	{VSTRT,     0x03},
	{VSIZE,     0x78},
	{HREF,      0x00},
	//tuned value for 80*60	
	//{HSTART,    0x20},
	//{HSIZE,     IMAGE_WIDTH>>2},
	//{VSTRT,     0x2f},
	//{VSIZE,     IMAGE_LENGTH>>1},
	//{HREF,      (IMAGE_LENGTH&0x01<<2)|(IMAGE_WIDTH&0x03)},
	{HOutSize,  IMAGE_WIDTH>>2},
	{VOutSize,  IMAGE_LENGTH>>1},
	{EXHCH,     (IMAGE_LENGTH&0x01<<2)|(IMAGE_WIDTH&0x03)},
	//{HOutSize,  0x50},
	//{VOutSize,  0x78},
	//{EXHCH,     0x00},
	{TGT_B,     0x7f},
	{FixGain,   0x09},
	{AWB_Ctrl0, 0xe0},
	{DSP_Ctrl1, 0xbf},
	{DSP_Ctrl2, 0x0c},
	{DSP_Ctrl3,	0x00},
	{DSP_Ctrl4, 0x00},
	{DSPAuto,		0xff},
	{SCAL0,			0x0a},
	{COM8,		  0xf0},
	{COM4,		  0xc1},
	{COM6,		  0xc5},
	{COM9,		  0x21},
	{BDBase,	  0xFF},
	{BDMStep,	  0x01},
	{AEW,		    0x34},
	{AEB,		    0x3c},
	{VPT,		    0xa1},
	{EXHCL,		  0x00},
	{AWBCtrl3,  0xaa},
	{COM8,		  0xff},
	{AWBCtrl1,  0x5d},
	{EDGE1,		  0x0a},
	{DNSOff,	  0x01},
	{EDGE2,		  0x01},
	{EDGE3,		  0x01},
	{MTX1,		  0x5f},
	{MTX2,		  0x53},
	{MTX3,		  0x11},
	{MTX4,		  0x1a},
	{MTX5,		  0x3d},
	{MTX6,		  0x5a},
	{MTX_Ctrl,  0x1e},
	{BRIGHT,	  0x00},
	{CNST,		  0x25},
	{USAT,		  0x65},
	{VSAT,		  0x65},
	{UVADJ0,	  0x11},
	{UVADJ1,	  0x02},
	{SDE,		    0x06},
	{GAM1,		  0x0e},
	{GAM2,		  0x1a},
	{GAM3,		  0x31},
	{GAM4,		  0x5a},
	{GAM5,		  0x69},
	{GAM6,		  0x75},
	{GAM7,		  0x7e},
	{GAM8,		  0x88},
	{GAM9,		  0x8f},
	{GAM10,		  0x96},
	{GAM11,		  0xa3},
	{GAM12,		  0xaf},
	{GAM13,		  0xc5},
	{GAM14,		  0xd7},
	{GAM15,		  0xe8},
	{SLOP,		  0x20},
	{HUECOS,	  0x80},
	{HUESIN,	  0x80},
	{DSPAuto,	  0xff},
	{DM_LNL,	  0x00},
	{BDBase,	  0x99},
	{BDMStep,	  0x03},
	{LC_YC,			0x00},
	{LC_RADI,	  0x00},
	{LC_COEF,	  0x13},
	{LC_XC,		  0x08},
	{LC_COEFB,  0x14},
	{LC_COEFR,  0x17},
	{LC_CTR,	  0x05},
	{COM3,		  0xd0},
	{COM5,			0xf5},
	{SIGN,			0x06},
	{REG16,			0x00},
	{COM10,			0x00},
	{0xff, 0x00}
};

#endif
