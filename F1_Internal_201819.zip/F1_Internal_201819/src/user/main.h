#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f10x.h"

int main(void);

#endif	/* __MAIN_H */
